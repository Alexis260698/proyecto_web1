<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="estiloFormularios.css">
	<title>Productos</title>
</head>
<body>
	<div class="body">
<center>
	<table>
		<thead >
			
			<tr>
				

		<th colspan="5">Usuarios</th>

			</tr>

		</thead>
		<tbody>
			
			<tr>

				<td>Id</td>
				<td>Nombre</td>
				<td>Password</td>
				<td>Tipo</td>
				
			
			</tr>

			<?php 

			include ("conexion.php");
			$query="SELECT * FROM usuarios";
			$resultado=$conexion->query($query);
			while ($row=$resultado->fetch_assoc()) {
			
			?>

			<tr>
				<td><?php echo $row['idusuario']; ?></td>
				<td><?php echo $row['nombreUsuario']; ?></td>
				<td><?php echo $row['pass']; ?></td>
				<td><?php echo $row['TipoUsuario']; ?></td>
				
			</tr>


			<?php  
		            } 
			?>





		</tbody>
	</table>
</center>
</div>
</body>

</html>