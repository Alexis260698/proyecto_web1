<!DOCTYPE html>
<html>
<head>

	<meta charset=UTF-8>	
    <title>Eliminar Productos</title>
    <script type="text/javascript" src="productoFormulario.js"></script>
    <link rel="stylesheet" type="text/css" href="estiloFormularios.css">
</head>
<Boby>

<div class="head">
	
<center><h1>  </h1></center>

</div>

	<CENTER>
	<div class="body"> <br><br>
	<form action="eliminarProducto.php" method="post" name="frmRegistro">
		 ID del Producto:
		<input type="text" name="idProducto" id="nombre" class="box" size="1px" autofocus="autofocus" required="required"><br><br>
		<input type="submit" name="btnAceptar" value="Eliminar Producto"  class="boton_personalizado" >
		<input type="reset" name="btnCancelar" value="Cancelar"  class="boton_personalizado2">
		<br>
		<br>
		<br>
	</form>	
    </div>
    </CENTER>
</Boby>
</html>	