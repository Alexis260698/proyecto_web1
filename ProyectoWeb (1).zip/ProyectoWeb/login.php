<?php
$usuario=$_GET['usuario'];
$pass=$_GET['pass'];
$a=0;

$mysql=new mysqli("localhost","root","","tienda");
$listaUser=$mysql->query("select * from usuarios");
foreach ($listaUser as $user) {
	if ($user['nombreUsuario']==$usuario) {
		$a=$a+1;
		if ($user['pass']==$pass) {
			
			header("Location:menu.html");
		}else{
			header("Location:index.php");
			
		}
	}else{
		header("Location:index.php");
	}
}

?>