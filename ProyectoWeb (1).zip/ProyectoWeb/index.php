<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="estilo.css">
	<title>Inicio</title>
</head>
<body>
	<div  class="head" align="center" >
<img class="imagen" src="img/carrito.png">
    </div>
<div>
<center><h1 class="texto" >Bienvenido</h1></center>
</div>
<div class="body">
<form action="login.php" method="get">
<center>	 
<br>
<br>
<br>
	 Usuario:
	 <br>
	 <br>
	  <input class="box" type="text" name="usuario" id="user" 
	 required="required"
	 placeholder="Usuario" 
	 autofocus></p>

	 Password:
	   <br>
	   <br>
	<input class="box" type="password" name="pass" id="password" 
	 required="required"
	 placeholder="Password"></p>

      <br>
      	 <input class="boton_personalizado" type="submit" value="Ingresar" />
	 <input class="boton_personalizado2" type="reset" value="Borrar" />
     
<br>
<br>
</center>
</form>
</div>
</body>
</html>