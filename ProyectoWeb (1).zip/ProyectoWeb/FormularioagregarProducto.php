<!DOCTYPE html>
<html>
<head>

	<meta charset=UTF-8>	
    <title>Registro de Productos</title>
    <script type="text/javascript" src="productoFormulario.js"></script>
    <link rel="stylesheet" type="text/css" href="estiloFormularios.css">
</head>
<Boby>

<div class="head">
	
<center><h1>  </h1></center>

</div>

	<CENTER>
	<div class="body"> <br><br>
	<form action="agregarProducto.php" method="post" name="frmRegistro">
		 Nombre del Producto:
		<input type="text" name="nombreProducto" id="nombre" class="box"  required="required" autofocus="autofocus"><br><br>
		 Precio del Producto:
		<input type="text" name="precioProducto" id="precio" required="required" size="1px" class="box"><br> <br>
		Cantidad en Stock:
		<input type="text" name="cantidadProducto" id="cantidad" required="required" size="1px" class="box"><br> <br>
		Descripcion del Producto:
		<input type="text" name="descripcionProducto" id="descripcion" size="50px" required="required"  class="box"><br> <br>


		<input name="btnAceptar" type="submit" value="Guardar Producto"  class="boton_personalizado" >
		<input name="btnCancelar" type="reset"  value="Cancelar"  class="boton_personalizado2" >
		<br>
		<br>
		<br>
	</form>	
    </div>
    </CENTER>
</Boby>
</html>	