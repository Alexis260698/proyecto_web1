<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="estiloFormularios.css">
	<title>Productos</title>
</head>
<body>
	<div class="body">
<center>
	<table>
		<thead >
			
			<tr>
				

		<th colspan="5">Productos</th>

			</tr>

		</thead>
		<tbody>
			
			<tr>

				<td>Id</td>
				<td>Nombre</td>
				<td>Precio</td>
				<td>Cantidad</td>
				<td>Descripcion</td>
				




			</tr>

			<?php 

			include ("conexion.php");
			$query="SELECT * FROM productos";
			$resultado=$conexion->query($query);
			while ($row=$resultado->fetch_assoc()) {
			
			?>

			<tr>
				<td><?php echo $row['idProducto']; ?></td>
				<td><?php echo $row['nombreProducto']; ?></td>
				<td><?php echo $row['PrecioProducto']; ?></td>
				<td><?php echo $row['Cantidad']; ?></td>
				<td><?php echo $row['Descripcion']; ?></td>
			</tr>


			<?php  
		            } 
			?>





		</tbody>
	</table>
</center>
</div>
</body>

</html>