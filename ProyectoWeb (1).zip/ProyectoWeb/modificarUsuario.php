<?php  


include("conexion.php");

$idUsuario= $_POST['idUser'];
$nombreUsuario= $_POST['nombreUser'];
$pass=$_POST['pass'];
$tipoUsuario=$_POST['tipoUser'];



$query="UPDATE usuarios SET idUsuario='$idUsuario', nombreUsuario='$nombreUsuario',pass='$pass', TipoUsuario='$tipoUsuario' WHERE idUsuario=$idUsuario";

        $resultado=$conexion->query($query);

if ($resultado) {

	 echo '<script type="text/javascript">alert(\'Operacion exitosa\');</script>'; 
	# code...
}
  






?>