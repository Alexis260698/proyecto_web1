<?php 
include("conexion.php");

$idEmpleado= $_POST['idEmpleado'];

$query="DELETE FROM usuarios WHERE idusuario=$idEmpleado";

        $resultado=$conexion->query($query);

if ($resultado) {

	 echo '<script type="text/javascript">alert(\'Operacion exitosa\');</script>'; 
	# code...
}

 ?>