<?php  

include("conexion.php");

$nombre= $_POST['nombreUsuario'];
$pass=$_POST['pass'];
$tipo=$_POST['tipoUsuario'];


$query="INSERT INTO usuarios(idusuario,nombreUsuario,pass,TipoUsuario) 
        VALUES (null,'$nombre','$pass','$tipo')";

        $resultado=$conexion->query($query);

?>