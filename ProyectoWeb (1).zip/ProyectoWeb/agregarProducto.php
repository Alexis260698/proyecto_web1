<?php  

include("conexion.php");

$nombre= $_POST['nombreProducto'];
$precio=$_POST['precioProducto'];
$stock=$_POST['cantidadProducto'];
$descripcion=$_POST['descripcionProducto'];

$query="INSERT INTO Productos(idProducto,nombreProducto,PrecioProducto,Cantidad,Descripcion) 
        VALUES (null,'$nombre','$precio','$stock','$descripcion')";

        $resultado=$conexion->query($query);
        if ($resultado) {
        	echo '<script type="text/javascript">alert(\'Operacion exitosa\');</script>'; 
        }else{

                echo '<script type="text/javascript">alert(\'Operacion fallida\');</script>'; 

        }


?>