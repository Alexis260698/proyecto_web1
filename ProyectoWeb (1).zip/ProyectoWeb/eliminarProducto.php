<?php 
include("conexion.php");

$idProducto= $_POST['idProducto'];

$query="DELETE FROM productos WHERE idProducto=$idProducto";

        $resultado=$conexion->query($query);

if ($resultado) {

	 echo '<script type="text/javascript">alert(\'Operacion exitosa\');</script>'; 
	# code...
}

 ?>