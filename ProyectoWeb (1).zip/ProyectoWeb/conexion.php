<?php 


$conexion = new mysqli("localhost","root","","tienda");

//if ($conexion) {

	//echo '<script type="text/javascript">alert(\'Operacion Exitosa\');</script>'; 
 
//} else {
  
  //echo '<script type="text/javascript">alert(\'Fallo la opracion\');</script>'; 

//}
?>