<?php  


include("conexion.php");

$idProducto= $_POST['idProducto'];
$nombre= $_POST['nombreProducto'];
$precio=$_POST['precioProducto'];
$stock=$_POST['cantidadProducto'];
$descripcion=$_POST['descripcionProducto'];


$query="UPDATE productos SET nombreProducto='$nombre', precioProducto='$precio',Cantidad='$stock', Descripcion='$descripcion' WHERE idProducto=$idProducto";

        $resultado=$conexion->query($query);

if ($resultado) {

	 echo '<script type="text/javascript">alert(\'Operacion exitosa\');</script>'; 
	# code...
}
  






?>