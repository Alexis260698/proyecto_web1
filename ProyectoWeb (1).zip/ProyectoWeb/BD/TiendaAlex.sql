CREATE database IF NOT EXISTS `tienda` DEFAULT CHARACTER SET utf8 ;
USE `tienda` ;

CREATE TABLE IF NOT EXISTS `tienda`.`usuarios` (
  `idusuario` INT NOT NULL AUTO_INCREMENT,
  `nombreUsuario` VARCHAR(45) NULL,
  `contraseña` VARCHAR(45) NULL,
  `TipoUsuario` VARCHAR(10) NULL,
  PRIMARY KEY (`idusuario`))
ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `tienda`.`Productos` (
  `idProducto` INT NOT NULL AUTO_INCREMENT,
  `nombreProducto` VARCHAR(45) NULL,
  `PrecioProducto` DOUBLE NULL,
  `Cantidad` INT NULL,
  `Descripcion` VARCHAR(50) NULL,
  PRIMARY KEY (`idProducto`))
ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `tienda`.`Ventas` (
  `idVenta` INT NOT NULL AUTO_INCREMENT,
  `FechaHoraVenta` LONGTEXT NULL,
  `Total` DOUBLE NULL,
  `idUsuarioVenta` INT NULL,
  PRIMARY KEY (`idVenta`),
  INDEX `idUsuario_idx` (`idUsuarioVenta` ASC) ,
  CONSTRAINT `idUsuario`
    FOREIGN KEY (`idUsuarioVenta`)
    REFERENCES `tienda`.`usuarios` (`idusuario`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;

CREATE TABLE IF NOT EXISTS `tienda`.`DetallesVentas` (
  `Ventas_idVenta` INT NOT NULL,
  `Productos_idProducto` INT NOT NULL,
  PRIMARY KEY (`Ventas_idVenta`, `Productos_idProducto`),
  INDEX `fk_Ventas_has_Productos_Productos1_idx` (`Productos_idProducto` ASC) ,
  INDEX `fk_Ventas_has_Productos_Ventas1_idx` (`Ventas_idVenta` ASC),
  CONSTRAINT `fk_Ventas_has_Productos_Ventas1`
    FOREIGN KEY (`Ventas_idVenta`)
    REFERENCES `tienda`.`Ventas` (`idVenta`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION,
  CONSTRAINT `fk_Ventas_has_Productos_Productos1`
    FOREIGN KEY (`Productos_idProducto`)
    REFERENCES `tienda`.`Productos` (`idProducto`)
    ON DELETE NO ACTION
    ON UPDATE NO ACTION)
ENGINE = InnoDB;